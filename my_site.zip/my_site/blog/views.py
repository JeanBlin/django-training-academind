from django.shortcuts import render
from django.http import Http404

posts_dict = {
    'Travel':{
        'text': 'I am going to visit Panama in November.',
        'image':'address of the image for the a tag'
    },
    'Training':{
        'text': 'I am learning Django, Machine Learning, and will soon start JS framworks like svelte.',
        'image':'address of the image for the a tag'
    },
    'Life':{
        'text': 'I just revceived my new laptop, Framework. Cannot wait to start using it.',
        'image':'address of the image for the a tag'
    },
}

# Create your views here.
def index(request):
    return render(request, 'blog/index.html')

def posts(request):
    return render(request, 'blog/posts.html', {'posts_dict':posts_dict})

def detailed_post(request):
    return render(request, 'blog/detailed_post.html')